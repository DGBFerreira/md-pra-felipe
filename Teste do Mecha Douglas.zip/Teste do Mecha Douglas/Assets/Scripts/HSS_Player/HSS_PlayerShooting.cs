﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HSS_PlayerShooting : MonoBehaviour
{
    public GameObject prefabDaBala;
    public Transform posicaoDaBala;

    public float fireDelay = 0.25f;
    float cooldownTimer = 0;

    void FixedUpdate()
    {
        cooldownTimer -= Time.deltaTime;

        if(Input.GetButton("Attack-Player1") && cooldownTimer <= 0)
        {
            cooldownTimer = fireDelay;
            Instantiate(prefabDaBala, posicaoDaBala.position, posicaoDaBala.rotation);
        }
    }
}

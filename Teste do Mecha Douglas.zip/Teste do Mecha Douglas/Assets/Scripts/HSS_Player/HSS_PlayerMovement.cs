﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HSS_PlayerMovement : MonoBehaviour
{
    // variavel de velocidade - 24/09/2019
    public float velocidade;
    public float min_y, max_y, min_x, max_x;

    [SerializeField] SpriteRenderer _Renderer;
    [SerializeField] SpritesMovimento[] MeusSprites;
    Dictionary<MovimentosPlayer, Sprite> SpritesDicionario = new Dictionary<MovimentosPlayer, Sprite>();

    Vector2 direction;

    void Start()
    {
        foreach (var _sprite in MeusSprites)
        {
            SpritesDicionario.Add(_sprite.Movimento, _sprite.sprite);
        }
    }

    void Update()
    {
        //24/09/2019
        float x = Input.GetAxisRaw("Horizontal-Player1");
        float y = Input.GetAxisRaw("Vertical-Player1");

        _Renderer.sprite = MeusSprites[0].sprite;

        //Direção do eixo - 24/09/2019
        direction = new Vector2(x, y).normalized;
    }

    private void FixedUpdate()
    {
        Move(direction);
        MoveAnimation(direction);
    }

    private void MoveAnimation(Vector2 direction)
    {
        if (Mathf.Abs(direction.x) > 0.1f && Mathf.Abs(direction.y) > 0.1f)
        {
            if (Mathf.Abs(direction.x) > 0.3f)
            {
                if (direction.x > 0)
                {
                    // Sprite para frente
                    _Renderer.sprite = SpritesDicionario[MovimentosPlayer.Frente];
                }
                else
                {
                    // Sprite para tras
                    _Renderer.sprite = SpritesDicionario[MovimentosPlayer.Tras];
                }
            }
            else
            {
                // Esta se movendo
                if (direction.y > 0)
                {
                    // Sprite para cima
                    _Renderer.sprite = SpritesDicionario[MovimentosPlayer.Cima];
                }
                else
                {
                    // Sprite para baixo
                    _Renderer.sprite = SpritesDicionario[MovimentosPlayer.Baixo];
                }
            }
        }
        else
        {
            // Idle
            _Renderer.sprite = SpritesDicionario[MovimentosPlayer.Idle];
        }
    }

    void Move(Vector2 direction)
    {
        

        //Pegar a posição do player - 24/09/2019
        Vector2 pos = transform.position;

        //Calcular a nova posição
        //pos += direction * velocidade * Time.deltaTime;

        pos += direction.x * (Vector2)transform.right * velocidade * Time.fixedDeltaTime;
        pos += direction.y * (Vector2)transform.up * velocidade * Time.fixedDeltaTime;

        //Pra garantir que a nova posição não vai ser fora da tela
        pos.x = Mathf.Clamp(pos.x, min_x, max_x);
        pos.y = Mathf.Clamp(pos.y, min_y, max_y);

        //Renovar a posição do player
        transform.position = pos;
    }
}

public enum MovimentosPlayer { Idle, Cima, Baixo, Frente, Tras};

[System.Serializable]
public class SpritesMovimento
{
    public MovimentosPlayer Movimento;
    public Sprite sprite;
}
